<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>  صور المتحركة خاصة بالصفحة الاوله</h1>
<a href="<?php echo e(route('sliders.create')); ?>" class="btn btn-primary"> <?php echo e(_('add slider')); ?></a>
    <table>
        <thead>
            <tr>
                <td> <?php echo e(_('ID')); ?></td>
                <td><?php echo e(_('image')); ?></td>
                <td><?php echo e(_('title')); ?></td>
                <td><?php echo e(_('date')); ?></td>
                <td><?php echo e(_('status')); ?></td>
                <td><?php echo e(_('action')); ?></td>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td> <?php echo e($s->id); ?></td>
                <td><a href="<?php echo e(route('sliders.show',$s->id)); ?>"><img src="<?php echo e(asset('frontend/img/'.$s->image)); ?>"  height="120px" width="120px" srcset="" ></a></td>
                <td><?php echo e($s->title); ?></td>
                <td><?php echo e($s->created_at); ?></td>
                <td> <?php if($s->active==1): ?> <?php echo e(_('active')); ?> <?php else: ?> <?php echo e(_('unactive')); ?><?php endif; ?></td>
                <td> <a href="<?php echo e(route('sliders.edit',$s->id)); ?>" class="btn btn-sm btn-danger"> <?php echo e(_('edit')); ?></a>
                    <form action="<?php echo e(route('sliders.destroy',$s->id)); ?>" method="post" class="d-inline-block"
                        onsubmit="return confirm('هل تريد حدف الصورة ');">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class=" btn btn-sm btn-danger"> <?php echo e(_('Delete')); ?></button>

                    </form>
                </td>
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc123\Desktop\DownTown\resources\views/admin/Slider/index.blade.php ENDPATH**/ ?>
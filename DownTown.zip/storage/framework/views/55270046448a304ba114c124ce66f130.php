<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-12">
            <form action="<?php echo e(route('sliders.update',$slider)); ?>" method="post"  enctype="multipart/form-data">
                // اضافة صور متحركه
                <?php echo csrf_field(); ?> // عملية تشفير البيانات
                <?php echo method_field('PUT'); ?>
                // خاص بتحميل الصور
                // البيانات الخاص بالصوره
                <div class="mb-3"> // عنوان الصورة
                    <label for="title "><?php echo e(_('Please Enter title')); ?></label>
                    <input type="text" id="title" name='slider_title' value="<?php echo e($slider->title); ?>" required >

                </div>

                <div class="mb-3">// عنوان فراعي
                    <label for="subtitle"><?php echo e(_('Please enter subtitle')); ?></label>
                    <input type="text" id="subtitle" name='image_subtitle' value="<?php echo e($slider->subtitle); ?>">
                </div>
                <div class="mb-3">
                    <label for="Description"><?php echo e(_('Pleasse enter description')); ?></label>
                    <textarea name="image_disc" id="Description" cols="30" rows="10" required> <?php echo e($slider->description); ?></textarea>
                </div>
                <div class="mb-3">
                    <label for="link"><?php echo e(_('please enter link ')); ?></label>
                    <input type="text" name="image_link" id="link" value="<?php echo e($slider->link); ?>">
                </div>
                <div class="mb-3">
                    <label for="active"><?php echo e(_('Is it to display')); ?></label>
                    <input type="checkbox" id='active' name="is_active" value="<?php echo e($slider->active); ?>">
                </div>
                <div class="mb-3">
                    <div class="image">
                        <img src="<?php echo e(asset('frontend/img/'.$slider->image)); ?>"   height="120px" width="120px" alt="" srcset="">
                    </div>
                    <label for="image"><?php echo e(_('upload image')); ?></label>
                    <input type="file" name="slider_image"  id="image" required>
                </div>
                <button type="submit" class="btn btn-success"><?php echo e(_('submit')); ?></button>

            </form>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.backapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc123\Desktop\DownTown\resources\views/admin/Slider/edit.blade.php ENDPATH**/ ?>